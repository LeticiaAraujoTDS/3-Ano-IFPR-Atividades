<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Aluno.php");

class AlunoDAO
{

    private PDO $conexao;

    public function __construct()
    {

        $this->conexao = Connection::getConnection();
    }

    public function inserir(Aluno $aluno)
    {
        $sql = "INSERT INTO alunos (nome, idade, estrangeiro, id_curso)
                VALUES (?,?,?,?)";
        $stm = $this->conexao->prepare($sql);
        try {
            $stm->execute(array(
                $aluno->getNome(),
                $aluno->getIdade(),
                $aluno->getEstrangeiro(),
                $aluno->getCurso()->getId()
            ));
            return null;
        } catch (PDOException $e) {
            return $e;
        }
    }

    public function listar()
    {
        $sql = "SELECT a.*,
                    c.nome nome_curso, c.turno turno_curso 
                FROM alunos a
                    JOIN cursos c ON (c.id = a.id_curso) order by a.id;";
        $stm = $this->conexao->prepare($sql);
        $stm->execute();
        $result = $stm->fetchAll();
        return $this->map($result);
    }

    private function map(array $result)
    {
        $alunos = array();
        foreach ($result as $r) {
            $aluno = new Aluno();
            $aluno->setId($r["id"]);
            $aluno->setNome($r["nome"]);
            $aluno->setIdade($r["idade"]);
            $aluno->setEstrangeiro($r["estrangeiro"]);

            $curso = new Curso();
            $curso->setId($r["id_curso"]);
            $curso->setNome($r["nome_curso"]);
            $curso->setTurno($r["turno_curso"]);
            $aluno->setCurso($curso);

            array_push($alunos, $aluno);
        }
        return $alunos;
    }

    public function buscarPorId(int $id)
    {
        $sql = "SELECT a.*,
                    c.nome nome_curso, c.turno turno_curso 
                FROM alunos a 
                    JOIN cursos c ON (c.id = a.id_curso) 
                    WHERE a.id = ?";
        $stm = $this->conexao->prepare($sql);
        $stm->execute([$id]);
        $result = $stm->fetchAll();
        //pegando o array de 1 aluno
        $alunos = $this->map($result);
        //verificar se está vazio
        if (count($alunos) > 0) {
            return $alunos[0];
        } else {
            return NULL;
        }
    }

    public function alterar(Aluno $aluno) {
        $sql = "UPDATE alunos SET  nome = ?, idade = ?, estrangeiro = ?, id_curso = ? WHERE alunos.id = ?";
        $stm = $this->conexao->prepare($sql);
        try {
            $stm->execute(array(
                $aluno->getNome(),
                $aluno->getIdade(),
                $aluno->getEstrangeiro(),
                $aluno->getCurso()->getId(), 
                $aluno->getId()
            ));
            return null;
        } catch (PDOException $e) {
            return $e;
        }
    }

    public function excluir(int $id) {
        $sql = "DELETE FROM alunos WHERE alunos.id = :id";
        $stm = $this->conexao->prepare($sql);
        try {
            $stm->bindValue("id", $id);
            $stm->execute();
            return null;
        } catch (PDOException $e) {
            return $e;
        }
    }
}
