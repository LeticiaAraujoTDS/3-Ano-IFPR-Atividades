<?php

require_once(__DIR__ . "/../dao/AlunoDAO.php");
require_once(__DIR__ . "/../model/Aluno.php");
require_once(__DIR__ . "/../service/AlunoService.php");

class AlunoController
{

    private AlunoDAO $alunoDAO;
    private AlunoService $alunoService;

    public function __construct()
    {

        $this->alunoDAO = new AlunoDAO;
        $this->alunoService = new AlunoService;
    }

    public function listar()
    {
        return $this->alunoDAO->listar();
    }

    public function buscarPorId($id)
    {
        return $this->alunoDAO->buscarPorId($id);
    }

    public function excluirPorId(int $id)
    {
        $erro = $this->alunoDAO->excluir($id);
        $erros = array();
        if ($erro) {
            array_push($erros, "Erro ao excluir o aluno.");
            if (AMB_DEV) {
                array_push($erros, $erro->getMessage());
            }
        }
        return $erro;
    }

    public function alterar(Aluno $aluno)
    {
        $erros = $this->alunoService->validarAluno($aluno);
        if (count($erros) > 0) {
            return $erros;
        }
        $erro = $this->alunoDAO->alterar($aluno);
        if ($erro != null) {
            array_push($erros, "Erro ao atualizar o aluno.");
            if (AMB_DEV) {
                array_push($erros, $erro->getMessage());
            }
        }
        return $erros;
    }

    public function inserir(Aluno $aluno)
    {
        $erros = $this->alunoService->validarAluno($aluno);
        if (count($erros) > 0) {
            return $erros;
        }
        $erro = $this->alunoDAO->inserir($aluno);
        if ($erro) {
            array_push($erros, "Erro ao salvar o aluno.");
            if (AMB_DEV) {
                array_push($erros, $erro->getMessage());
            }
        }
        return $erros;
    }
}
