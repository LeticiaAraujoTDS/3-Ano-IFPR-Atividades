<?php
require_once(__DIR__ . "/../../controller/CursoController.php");
$cursoCont = new CursoController();
$lista = $cursoCont->listar();
include_once(__DIR__ . "/../include/header.php");
?>

<!-- <h3> // $aluno && $aluno->getId() > 0 ? 'Alterar' : 'Inserir'  Aluno</h3> -->
<div class="row">

    <div class="col-6">

        <form method="POST" action="">
            <!-- tá escondido -->
            <input name="id" type="hidden" value="<?= $aluno ? $aluno->getId() : 0 ?>">
            <div>
                <label for="txtNome" class="form-label">Nome:</label>
                <input name="nome" type="text" id="txtNome" placeholder="Informe o nome . . ." class=" form-control" value="<?= $aluno  != null ? $aluno->getNome() : '' ?>">
            </div>

            <div>
                <label for="txtIdade" class=" form-label">Idade:</label>
                <input name="idade" type="number" id="txtIdade" placeholder="Informe a idade . . ." class="form-control" value="<?= $aluno  != null ? $aluno->getIdade() : '' ?>">
            </div>

            <div>
                <label for="selEstrang" class=" form-label">Estrangeiro:</label>
                <select name="estrang" id="selEstrang" class=" form-select">
                    <option value="">---Selecione---</option>
                    <option value="S" <?= $aluno && $aluno->getEstrangeiro() == 'S' ? 'selected' : '' ?>>Sim</option>
                    <option value="N" <?= $aluno && $aluno->getEstrangeiro() == 'N' ? 'selected' : '' ?>>Não</option>
                </select>
            </div>

            <div>
                <label for="selCurso" class="form-label">Curso:</label>
                <select name="curso" id="idCurso" class=" form-select">
                    <option value="">---Selecione---</option>
                    <?php foreach ($lista as $curso): ?>
                        <option value="<?= $curso->getID() ?>" <?= $aluno && $aluno->getCurso() && $aluno->getCurso()->getId() == $curso->getId() ? 'selected' : '' ?>>
                            <?= $curso ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class=" mt-3">
                <button type="submit" class="btn btn-success">Enviar</button>
            </div>


        </form>
    </div>

    <div class="col-6">
        <?php if($msgErro):?>
        <div class=" alert-danger">
            <?= $msgErro ?>
        </div>
        <?php endif ?>
    </div>


</div>
<!-- < fecha a linha  -->
<div class=" mt-3">

    <button class=" btn btn-outline-success"><a href="listar.php">Voltar</a></button>
</div>

<?php
include_once(__DIR__ . "/../include/footer.php");
?>