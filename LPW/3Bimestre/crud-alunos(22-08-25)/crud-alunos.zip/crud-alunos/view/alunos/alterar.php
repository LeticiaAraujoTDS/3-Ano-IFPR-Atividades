<?php
require_once(__DIR__ . "/../../model/Aluno.php");
require_once(__DIR__ . "/../../controller/AlunoController.php");

$msgErro = "";
$aluno = null;

//testa se o usuario já clicou em gravar
if (isset($_POST["nome"])) {
    //já clicou em gravar
    // echo "Já clicou!"; 

    //1 - Capturar os dados do formulário
    $id = is_numeric($_POST['id']) ? $_POST['id'] : null;
    $nome = trim($_POST['nome']) ? trim($_POST['nome']) : null;
    $idade = is_numeric($_POST['idade']) ? $_POST['idade'] : null;
    $estrangeiro = trim($_POST['estrang']) ? trim($_POST['estrang']) : null;
    $idCurso = is_numeric($_POST['curso']) ? $_POST['curso'] : null;

    //Criar um objeto ALuno para persisti-lo
    $aluno = new Aluno(); // é um objeto
    $aluno->setId($id);
    $aluno->setNome($nome);
    $aluno->setIdade($idade);
    $aluno->setEstrangeiro($estrangeiro);

    $curso = new Curso(); // é um objeto
    $curso->setId($idCurso);
    $aluno->setCurso($curso);


    // 2 - Chamar o controler
    $alunoCont = new AlunoController();
    $erros = $alunoCont->alterar($aluno);

    if (!$erros) {
        header("Location:listar.php");
    } else {
        //converter o array de erros para string
        $msgErro = implode("<br>", $erros);
    }
} else {
    //só abriu o form

    if (isset($_GET["id"])) {
        $id = $_GET["id"];
    } else {
    }

    $alunoCont = new AlunoController();
    $aluno = $alunoCont->buscarPorId($id);

    if (! $aluno) {
        echo "ID do aluno é inválido!<br>";
        echo "<a href='listar.php'>Voltar</a>";
        exit;
    }

    // print_r($aluno);
    // exit;

}
include_once(__DIR__ . "/form.php");
