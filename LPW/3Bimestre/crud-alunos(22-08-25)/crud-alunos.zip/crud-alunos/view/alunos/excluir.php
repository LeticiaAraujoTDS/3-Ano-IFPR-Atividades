<?php
require_once(__DIR__ . "/../../controller/AlunoController.php");

//1 - Receber o ID do aluno (GET)
$id = 0;

if (isset($_GET['id']))
    $id = $_GET['id'] ?? null;

// 2 - Chamar o controller
$alunoCont = new AlunoController();
$aluno = $alunoCont->buscarPorId($id);

// 2.1 - Se achou
if ($aluno) {
    //2.2 - Chamar o controller para excluir
    $erros = $alunoCont->excluirPorId($aluno->getId());
    if ($erros) {
        // 2.4 - Se deu ERRO
        $msgErro = implode("<br>", $erros);
        echo $msgErro;
        echo "<a href='listar.php'>Voltar</a>";
        exit;
    } else {
        // 2.5 - Se deu CERTO
        header("Location: listar.php");
        exit;
    }
} else {
    echo "Aluno não encontrado!<br>";
    echo "<a href='listar.php'>Voltar</a>";
    exit;
}
