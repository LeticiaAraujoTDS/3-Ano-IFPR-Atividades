<?php

require_once(__DIR__ . "/../model/Aluno.php");

class AlunoService {

    public function validarAluno(Aluno $aluno) {
        $erros = array();


        if ($aluno->getNome() == null) {
            array_push($erros, "Informe o nome do aluno!");
        }
        if (!$aluno->getIdade()) {
            array_push($erros, "Informe a idade do aluno!");
        }
        if ($aluno->getEstrangeiro() == null) {
            array_push($erros, "Informe se o aluno é estrangeiro!");
        }
        if ($aluno->getCurso()->getId() == null) {
            array_push($erros, "Informe o curso!");
        }
        return $erros;
    }
}