<?php
require_once(__DIR__ . "/../../controller/CursoController.php");
$cursoCont = new CursoController();
$lista = $cursoCont->listar();
include_once(__DIR__ . "/../include/header.php");
?>

<h3>Inserir alunos</h3>

<form method="POST" action="">
    <div>
        <input type="hidden" value="<?= $aluno != null ? $aluno->getId() : '' ?>">
    </div>
    <div>
        <label for="txtNome">Nome:</label>
        <input name="nome" type="text" id="txtNome" placeholder="Informe o nome . . ." value="<?= $aluno  != null ? $aluno->getNome() : ''?>">
    </div>

    <div>
        <label for="txtIdade">Idade:</label>
        <input name="idade" type="number" id="txtIdade" placeholder="Informe a idade . . ." value="<?= $aluno  != null ? $aluno->getIdade() : ''?>">
    </div>

    <div>
        <label for="selEstrang">Estrangeiro:</label>
        <select name="estrang" id="selEstrang">
            <option value="">---Selecione---</option>
            <option value="S" <?= $aluno && $aluno->getEstrangeiro() == 'S' ? 'selected': ''?>>Sim</option>
            <option value="N" <?= $aluno && $aluno->getEstrangeiro() == 'N' ? 'selected': ''?>>Não</option>
        </select>
    </div>

    <div>
        <label for="selCurso">Curso:</label>
        <select name="curso" id="idCurso">
            <option value="">---Selecione---</option>
            <?php foreach ($lista as $curso): ?>
                <option value="<?= $curso->getID() ?>" <?= $aluno && $aluno->getCurso() && $aluno->getCurso()->getId() == $curso->getId() ? 'selected' : '' ?>>
                    <?= $curso ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div>
        <button type="submit">Enviar</button>
    </div>
    

</form>

<div class="mensagens" style="color: darkred;">
    <?= $msgErro ?>
</div>

<div>
    <button><a href="listar.php">Voltar</a></button>
</div>

<?php
include_once(__DIR__ . "/../include/footer.php");
?>