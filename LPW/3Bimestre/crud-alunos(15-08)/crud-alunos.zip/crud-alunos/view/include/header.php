<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crud Alunos</title>
    <style>
        body {
            background-color: #abebf0ff;
            color: #023c41ff;
        }
        a {
            text-decoration: none;
        }
        button {
            text-decoration: none;
            color: #00626bff;
            background-color: white;
        }
        button:hover {
            background-color: #002b2eff;
            color: white;
            transition: all ease-in-out 0.8s;
        }
        input:hover, select:hover, option:hover {
            background-color: #e2fdffff;
            transition: all ease-in-out 0.8s;
        }
    </style>
</head>
<body>