<?php

require_once(__DIR__ . "/../dao/AlunoDAO.php");
require_once(__DIR__ . "/../model/Aluno.php");
require_once(__DIR__ . "/../service/AlunoService.php");

class AlunoController{

    private AlunoDAO $alunoDAO;
    private AlunoService $alunoService;

    public function __construct() {

        $this->alunoDAO = new AlunoDAO;
        $this->alunoService = new AlunoService;
    }

    public function listar(){
        return $this->alunoDAO->listar();
    }

    public function buscarPorId($id) {
        return $this->alunoDAO->buscarPorId($id);
    }

    public function alterar(Aluno $aluno) {
        return $this->alunoDAO->alterar($aluno);
    }

    public function inserir(Aluno $aluno) {
        $erros = $this->alunoService->validarAluno($aluno);
        if (count($erros) > 0) {
            return $erros;
        }
        $erro = $this->alunoDAO->inserir($aluno);
        if ($erro) {
            array_push($erros, "Erro ao salvar o aluno.");
            if (AMB_DEV) {
                array_push($erros, $erro->getMessage());
            }
        } 
        return $erros;
    }
}