<!-- Footer -->
<footer class="bg-light fixed-bottom text-muted mt-3">
    <div class="text-center p-4">
        © 2025 Copyright:
        <a href="https://foz.ifpr.edu.br"
            target="blank">IFPR (Campus Foz do Iguaçu)</a>
    </div>
</footer>

</div> <!-- Fecha a div container aberta no header.php -->

<!-- Inclusão do JS do Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script>

</body>

</html>