<?php

require_once(__DIR__ . "/../model/Usuario.php");
require_once(__DIR__ . "/../util/config.php");

class LoginService
{

    public function validarLogin(?string $login, ?string $senha)
    {
        $erros = array();

        if (!$login) {
            array_push($erros, "Informe o login!");
        }

        if (!$senha) {
            array_push($erros, "Informe a senha!");
        }
        return $erros;
    }
    public function salvarUsuarioSessao(Usuario $usuario)
    {
        $this->iniciarSessao();
        $_SESSION[SESSAO_USUARIO_ID] = $usuario->getId();
        $_SESSION[SESSAO_USUARIO_NOME] = $usuario->getNome();
    }
    public function apagarDadosSessao()
    {
        $this->iniciarSessao();

        //REMOVER OS DADOS DA SESSÃO
        session_unset();

        //DESTROI A SESSÃO
        session_destroy();
    }
    public function getNomeUsuarioLogado()
    {
        $this->iniciarSessao();
        if ($this->usuarioEstaLogado()) {
            return $_SESSION[SESSAO_USUARIO_NOME];
        }
        return "(Não autenticado)";
    }
    public function usuarioEstaLogado()
    {
        $this->iniciarSessao();
        if (isset($_SESSION[SESSAO_USUARIO_ID])) {
            return true;
        } else {
            return false;
        }
    }
    private function iniciarSessao()
    {
        if (session_status() != PHP_SESSION_ACTIVE)
            session_start();
    }
}
