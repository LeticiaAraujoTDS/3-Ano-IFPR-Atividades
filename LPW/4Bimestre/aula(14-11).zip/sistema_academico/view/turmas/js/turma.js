const selCurso = document.querySelector("#selCurso");
const selDisciplina = document.querySelector("#selDisciplina");
const spanUrlBase = document.querySelector("#confUrlBase").dataset.urlBase;
console.log(spanUrlBase);

const divErro = document.getElementById("divMsgErro");

function carregarDisciplinas() {
    selDisciplina.innerHTML = "";
    var selecione = { "id": 0, "codigo": "---", "nome": "Selecione - ---" };
    adicionarOptionDisciplina(selecione);
    var url = spanUrlBase + "/api/disciplinas_por_curso.php?id=" + selCurso.value;
    var xhttp = new XMLHttpRequest();
    xhttp.open("GET", url);//o true já e padrrao

    //funcao de callback sera executada quando chegar a resposta da requisição
    xhttp.onload = function () {
        var json = xhttp.responseText;

        //criar as options com base na resposta recebida em json
        var disciplinas = JSON.parse(json);
        disciplinas.forEach(d => {
            //console.log(d.id + " - " + d.nome);
            adicionarOptionDisciplina(d);
        });
    }

    xhttp.send();


}



// carregarDisciplinasSicrona()
function carregarDisciplinasSicrona() {
    selDisciplina.innerHTML = "";
    var selecione = { "id": 0, "codigo": "---", "nome": "Selecione - ---" };
    adicionarOptionDisciplina(selecione);
    var url = "/Leticia3TDS/sistema_academico/api/disciplinas_por_curso.php?id=" + selCurso.value;
    var xhttp = new XMLHttpRequest();
    xhttp.open("GET", url, false);
    xhttp.send();

    var json = xhttp.responseText;
    var disciplinas = JSON.parse(json);
    disciplinas.forEach(d => {
        //console.log(d.id + " - " + d.nome);
        adicionarOptionDisciplina(d);
    });
}


function adicionarOptionDisciplina(disciplina) {
    var option = document.createElement("option");
    option.value = disciplina.id;
    option.innerHTML = disciplina.codigo + " - " + disciplina.nome;
    //marcar o option
    const idSelecionado = selDisciplina.getAttribute("idSelecionado");
    if (idSelecionado == disciplina.id) {
        option.setAttribute("selected", "true");
    }
    selDisciplina.appendChild(option);
}

function salvarTurma() {
    const ano = document.querySelector("#txtAno").value;
    const curso = selCurso.value;
    const disciplina = selDisciplina.value;

    //alert(ano + " - " + curso + " - " + disciplina);
    const dados = new FormData();
    dados.append("ano", ano);
    dados.append("idCurso", curso);
    dados.append("idDisc", disciplina);

    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", spanUrlBase + "/api/turmas_salvar.php");
    xhttp.onload = function () {
        //console.log(xhttp.responseText);
        const erros = xhttp.responseText;
        if (erros) {
            //exibir os erros
            divErro.innerHTML = erros;
            divErro.style.display = "block";
        } else {
            //salvou a turma, redirecionar para o listar
            window.location = "listar.php";
        }
    };

    xhttp.send(dados);
}