<?php 
require_once(__DIR__ . "/../model/Turma.php");
require_once(__DIR__ . "/../controller/TurmaController.php");

$ano = is_numeric($_POST['ano']) ? $_POST['ano'] : null ;
$idCurso = is_numeric($_POST['idCurso']) ? $_POST['idCurso'] : null;
$idDisc = is_numeric($_POST['idDisc']) ? $_POST['idDisc'] : 0;

//echo $ano . " - " . $idCurso . " - " . $idDisc; aparece no console
//criar o objeto

$turma = new Turma();
$turma->setAno($ano);
$turma->setDisciplina(new Disciplina($idDisc));

//print_r($turma);

$turmaCont = new TurmaController();
$erros = $turmaCont->salvar($turma);

$msgErro = "";
if($erros){
    $msgErro = implode("<br>", $erros);
}
echo $msgErro;