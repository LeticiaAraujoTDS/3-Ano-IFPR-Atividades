<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Animal.php");

class AnimalDAO
{

    private PDO $conexao;

    public function __construct()
    {

        $this->conexao = Connection::getConnection();
    }

    public function inserir(Animal $animal)
    {
        $sql = "INSERT INTO animais (nome, classificacao, especie, porte, id_habitat, id_funcionario)
                VALUES (?,?,?,?,?,?)";
        $stm = $this->conexao->prepare($sql);
        try {
            $stm->execute(array(
                $animal->getNome(),
                $animal->getClassificacao(),
                $animal->getEspecie(),
                $animal->getPorte(),
                $animal->getHabitat()->getId(),
                $animal->getFuncionario()->getId()
            ));
            return null;
        } catch (PDOException $e) {
            return $e;
        }
    }

    public function listar()
    {
       $sql = "SELECT a.*,
               f.nome AS nome_funcionario,
               f.cargo AS cargo_funcionario,
               h.nome AS nome_habitat,
               h.tipo AS tipo_habitat
        FROM animais a
        JOIN funcionarios f ON f.id = a.id_funcionario
        JOIN habitats h ON h.id = a.id_habitat
        ORDER BY a.id";

        $stm = $this->conexao->prepare($sql);
        $stm->execute();
        $result = $stm->fetchAll();
        return $this->map($result);
    }

    private function map(array $result)
    {
        $animais = array();
        foreach ($result as $r) {
            $animal = new Animal();
            $animal->setId($r["id"]);
            $animal->setNome($r["nome"]);
            $animal->setClassificacao($r["classificacao"]);
            $animal->setEspecie($r["especie"]);
            $animal->setPorte($r["porte"]);

            $funcionario = new Funcionario();
            $funcionario->setId($r["id_funcionario"]);
            $funcionario->setNome($r["nome_funcionario"]);
            $funcionario->setCargo($r["cargo_funcionario"]);
            $animal->setFuncionario($funcionario);

            $habitat = new Habitat();
            $habitat->setId($r["id_habitat"]);
            $habitat->setNome($r["nome_habitat"]);
            $habitat->setTipo($r["tipo_habitat"]);
            $animal->setHabitat($habitat);

            array_push($animais, $animal);
        }
        return $animais;
    }

   public function buscarPorId(int $id)
{
    $sql = "SELECT a.*,
                   f.nome AS nome_funcionario, f.cargo AS cargo_funcionario,
                   h.nome AS nome_habitat, h.tipo AS tipo_habitat
            FROM animais a
            JOIN funcionarios f ON f.id = a.id_funcionario
            JOIN habitats h ON h.id = a.id_habitat
            WHERE a.id = ?";

    $stm = $this->conexao->prepare($sql);
    $stm->execute([$id]);
    $result = $stm->fetchAll();

    $animais = $this->map($result);

    if (count($animais) > 0) {
        return $animais[0];
    } else {
        return null;
    }
}


    public function alterar(Animal $animal) {
        $sql = "UPDATE animais SET  nome = ?, classificacao = ?, especie = ?, porte = ?, id_funcionario = ?, id_habitat = ?  WHERE animais.id = ?";
        $stm = $this->conexao->prepare($sql);
        try {
            $stm->execute(array(
                $animal->getNome(),
                $animal->getClassificacao(),
                $animal->getEspecie(),
                $animal->getPorte(),
                $animal->getFuncionario()->getId(),
                $animal->getHabitat()->getId(), 
                $animal->getId()
            ));
            return null;
        } catch (PDOException $e) {
            return $e;
        }
    }

    public function excluir(int $id) {
        $sql = "DELETE FROM animais WHERE animais.id = :id";
        $stm = $this->conexao->prepare($sql);
        try {
            $stm->bindValue("id", $id);
            $stm->execute();
            return null;
        } catch (PDOException $e) {
            return $e;
        }
    }
}
