<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Funcionario.php");

class FuncionarioDAO
{

    private PDO $conexao;

    public function __construct()
    {

        $this->conexao = Connection::getConnection();
    }

    public function listar()
    {
        $sql = "SELECT * FROM funcionarios ORDER BY nome";
        $stm = $this->conexao->prepare($sql);
        $stm->execute();
        $resultado = $stm->fetchAll();
        return $this->map($resultado);
    }

    //arrumar funcao para pegar os funcionarios no id do habitat e mandar pra o ajax
    public function listaPorHabitat(int $idHabitat) {
        $sql = "SELECT f.*, c.nome AS nome_curso, c.turno AS turno_curso" . 
               " FROM funcionarios f" .
               " JOIN habitats c ON (c.id = d.id_curso)" .
               " WHERE d.id_curso = ?" . 
               " ORDER BY d.nome";
        $stm = $this->conexao->prepare($sql);    
        $stm->execute([$idHabitat]);
        $result = $stm->fetchAll();

        return $this->map($result);
    }


    private function map(array $resultado)
    {
        $funcionarios = array();
        foreach ($resultado as $r) {
            $funcionario = new Funcionario();
            $funcionario->setId($r["id"]);
            $funcionario->setNome($r["nome"]);
            $funcionario->setCargo($r["cargo"]);

            array_push($funcionarios, $funcionario);
        }
        return $funcionarios;
    }
}
