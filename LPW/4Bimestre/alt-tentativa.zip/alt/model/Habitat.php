<?php

class Habitat
{
    private ?int $id;
    private ?string $nome;
    private ?string $tipo; //tratamento de 1 caracter

    /**
     * Get the value of id
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId(?int $id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of nome
     */
    public function getNome(): ?string
    {
        return $this->nome;
    }

    /**
     * Set the value of nome
     */
    public function setNome(?string $nome): self
    {
        $this->nome = $nome;

        return $this;
    }

    /**
     * Get the value of tipo
     */
    public function getTipo(): ?string
    {
        return $this->tipo;
    }

    public function getTipoTexto(): ?string
    {
        switch ($this->getTipo()) {
            case 'T':
                return 'Terrestre';
                break;
            case 'A':
                return 'Aquático';
                break;
            case 'H':
                return 'Híbrido';
                break;
            case 'V':
                return 'Viveiro';
                break;
            default:
                return 'Tipo não reconhecido. Informe um valor válido!.';
                break;
        }
    }

    /**
     * Set the value of tipo
     */
    public function setTipo(?string $tipo): self
    {
        $this->tipo = $tipo;

        return $this;
    }
}
