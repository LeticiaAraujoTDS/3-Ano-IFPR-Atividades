<?php

require_once(__DIR__ . "/Funcionario.php");
require_once(__DIR__ . "/Habitat.php");

class Animal
{
    private ?int $id;
    private ?string $nome;
    private ?string $classificacao; //tratamento de 1 caracter
    private ?string $especie;
    private ?string $porte; //tratamento de 1 caracter
    private ?Funcionario $funcionario;
    private ?Habitat $habitat;


    /**
     * Get the value of id
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId(?int $id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of nome
     */
    public function getNome(): ?string
    {
        return $this->nome;
    }

    /**
     * Set the value of nome
     */
    public function setNome(?string $nome): self
    {
        $this->nome = $nome;

        return $this;
    }

    /**
     * Get the value of classificacao
     */
    public function getClassificacao(): ?string
    {
        return $this->classificacao;
    }

    public function getClasTexto(): ?string
    {
        switch ($this->getClassificacao()) {
            case 'M':
                return 'Mamíferos';
                break;
            case 'A':
                return 'Anfíbios';
                break;
            case 'R':
                return 'Répteis';
                break;
            case 'V':
                return 'Aves';
                break;
            case 'P':
                return 'Peixes';
                break;
            default:
                return 'Tipo não reconhecido. Informe um valor válido!.';
                break;
        }
    }

    /**
     * Set the value of classificacao
     */
    public function setClassificacao(?string $classificacao): self
    {
        $this->classificacao = $classificacao;

        return $this;
    }

    /**
     * Get the value of especie
     */
    public function getEspecie(): ?string
    {
        return $this->especie;
    }

    /**
     * Set the value of especie
     */
    public function setEspecie(?string $especie): self
    {
        $this->especie = $especie;

        return $this;
    }

    /**
     * Get the value of porte
     */
    public function getPorte(): ?string
    {
        return $this->porte;
    }
    public function getPorteTexto(): ?string
    {
        switch ($this->getPorte()) {
            case 'G':
                return 'Grande';
                break;
            case 'M':
                return 'Médio';
                break;
            case 'P':
                return 'Pequeno';
                break;
            default:
                return 'Porte não reconhecido. Informe um valor válido!.';
                break;
        }
    }
    /**
     * Set the value of porte
     */
    public function setPorte(?string $porte): self
    {
        $this->porte = $porte;

        return $this;
    }

    /**
     * Get the value of funcionario
     */
    public function getFuncionario(): ?Funcionario
    {
        return $this->funcionario;
    }

    /**
     * Set the value of funcionario
     */
    public function setFuncionario(?Funcionario $funcionario): self
    {
        $this->funcionario = $funcionario;

        return $this;
    }

    /**
     * Get the value of habitat
     */
    public function getHabitat(): ?Habitat
    {
        return $this->habitat;
    }

    /**
     * Set the value of habitat
     */
    public function setHabitat(?Habitat $habitat): self
    {
        $this->habitat = $habitat;

        return $this;
    }
}
