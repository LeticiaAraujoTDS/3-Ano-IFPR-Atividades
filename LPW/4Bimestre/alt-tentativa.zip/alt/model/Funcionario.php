<?php

class Funcionario
{

    private ?int $id;
    private ?string $nome;
    private ?string $cargo;

    /**
     * Get the value of id
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId(?int $id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of nome
     */
    public function getNome(): ?string
    {
        return $this->nome;
    }

    /**
     * Set the value of nome
     */
    public function setNome(?string $nome): self
    {
        $this->nome = $nome;

        return $this;
    }

    /**
     * Get the value of cargo
     */
    public function getCargo(): ?string
    {
        return $this->cargo;
    }

    /**
     * Set the value of cargo
     */
    public function setCargo(?string $cargo): self
    {
        $this->cargo = $cargo;

        return $this;
    }
}
