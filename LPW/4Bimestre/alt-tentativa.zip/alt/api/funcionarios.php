<?php
require_once(__DIR__ . "/../controller/FuncionarioController.php");

$funcionarioCont = new FuncionarioController();
$funcionarios = $funcionarioCont->listar();

$funcionarios_array = [];
foreach ($funcionarios as $f) {
    $texto = $f->getNome() . " (" . $f->getCargo() . ")";
    
    $funcionarios_array[] = [
        'id' => $f->getId(),
        'nome' => $texto
    ];
}

echo json_encode($funcionarios_array, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);