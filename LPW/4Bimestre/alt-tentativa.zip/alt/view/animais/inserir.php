<?php

require_once(__DIR__ . "/../../model/Animal.php");
require_once(__DIR__ . "/../../controller/AnimalController.php");

$msgErro = "";
$animal = null;


//Recebe os dados do formulário
if (isset($_POST['txtNome']) && isset($_POST['selClassificacao']) && isset($_POST['txtEspecie']) && isset($_POST['selHabitat']) && isset($_POST['selFuncionario']) && isset($_POST['selPorte'])) {

    //Usuário já clicou no gravar
    $nome = trim($_POST['txtNome']) ? trim($_POST['txtNome']) : NULL;
    $classificacao = $_POST['selClassificacao'] ? $_POST['selClassificacao'] : NULL;
    $especie = trim($_POST['txtEspecie']) ? trim($_POST['txtEspecie']) : NULL;
    $idHabitat = $_POST['selHabitat'] ? $_POST['selHabitat'] : NULL;
    $idFuncionario = $_POST['selFuncionario'] ? $_POST['selFuncionario'] : NULL;
    $porte = $_POST['selPorte'] ? $_POST['selPorte'] : NULL;

    //Criar um objeto Animal para persistí-lo
    $animal = new Animal();
    $animal->setId(0); //Novo animal, então o ID é 0
    $animal->setNome($nome);
    $animal->setClassificacao($classificacao);
    $animal->setEspecie($especie);
    $habitat = new Habitat();
    $habitat->setId($idHabitat);
    $animal->setHabitat($habitat);
    $funcionario = new Funcionario();
    $funcionario->setId($idFuncionario);
    $animal->setFuncionario($funcionario);
    $animal->setPorte($porte);

    //Chama o DAO para salvar o objeto Animal
    $animalCont = new AnimalController();
    $erros = $animalCont->inserir($animal);

     //Se não houver erros

    if (!$erros) {
         //Redireciona para a listagem
        header("location: listar.php");
        exit;
    } else{
        //Converte o array de erros para string
        $msgErro = implode("<br>", $erros);
        
    }

}

include_once(__DIR__ . "/form.php");

?>