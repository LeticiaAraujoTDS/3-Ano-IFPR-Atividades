<?php 

//Mostrar erros do PHP
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once(__DIR__ . "/../../controller/AnimalController.php");

//CHAMA CONTROLLER PARA OBTER A LSITA DE BICHOS
$animalCont = new AnimalController();
$lista = $animalCont->listar();

//print_r($lista);


//INCLUIR O HEADER
include_once(__DIR__ . "/../include/header.php");


?>

<h3>LISTAGEM DE ANIMAIS</h3>



<table class="table table-striped ">

<!-- Cabeçalho -->

<tr>
    <th>ID</th>
    <th>Nome</th>
    <th>Classificação</th>
    <th>Espécie</th>
    <th>Habitat</th>
    <th>Funcionário</th>
    <th>Porte</th>
    <th>Alterar</th>
    <th>Excluir</th>  
    
</tr>

<!--Dados-->

<?php foreach ($lista as $animal): ?> 

    <tr>
        <td><?= $animal->getId()?></td>
        <td><?= $animal->getNome()?></td>
        <td><?= $animal->getClasTexto()?></td>
        <td><?= $animal->getEspecie()?></td>
        <td><?= $animal->getHabitat()->getNome() . " (" . $animal->getHabitat()->getTipoTexto() . ")"?></td>
        <td><?= $animal->getFuncionario()->getNome()?></td>
        <td><?= $animal->getPorteTexto()?></td>
        <td>
        <a href="alterar.php?id=<?= $animal->getId() ?>">
            <img src="../../img/btn_editar.png" alt="Editar">
        </a>
    </td>
    <td>
        <a href="excluir.php?id=<?= $animal->getId() ?>" onclick="return confirm('Confirma a exclusão?')">
            <img src="../../img/btn_excluir.png" alt="Excluir">
        </a>
</td>

    
    </tr>
<?php endforeach; ?>



</table>

<div class="mb-3">
    <a href="inserir.php" class="btn btn-primary">Para inserir os dados!</a>
</div>

<?php 
include_once(__DIR__ . "/../include/footer.php");

//INCLUIR FOOTER

?>