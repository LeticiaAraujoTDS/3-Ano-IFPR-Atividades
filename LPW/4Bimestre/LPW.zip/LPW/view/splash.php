<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="imagens" href="../img/abobora.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../styles/splash.css">
    <title>Contador de Abobóras</title>

</head>
<body>

<div class="splash-conteudo">

        <img src="../img/a.gif" alt="Splash Image" class="img-fluid"> 
        <!-- o img-fluid é para deixar a imagem responsiva -->
    </div>

    <script>
         setTimeout(function () {
             window.location.href = "../view/home.php";
         }, 3000);

    </script>
</body>
</html>