<?php
require_once(__DIR__ . "/../controller/AboboraController.php");

$aboboraCont = new AboboraController();

$msg = $aboboraCont->remover();

if ($msg) {
    header("Location: ../view/home.php?msg=2");
    exit;
} else {
    header("Location: ../view/home.php?msg=3");
    exit;
}
