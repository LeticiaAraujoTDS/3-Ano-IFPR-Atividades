<?php
header("Location: view/splash.php");
?>