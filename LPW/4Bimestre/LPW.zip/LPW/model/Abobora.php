<?php

require_once(__DIR__ . "/../util/config.php");

class Abobora
{
    private int $abobora;

    public function __construct(){
        if (session_status() != PHP_SESSION_ACTIVE)
            session_start();
    }

    /**
     * Get the value of abobora
     */
    public function getAbobora(): int
    {
        return $_SESSION[SESSAO_VALOR] ?? $this->abobora;
    }

    /**
     * Set the value of abobora
     */
    public function setAbobora(int $abobora): self
    {
        $this->abobora = $abobora;
        $_SESSION[SESSAO_VALOR] = $this->abobora;
        return $this;
    }
}
