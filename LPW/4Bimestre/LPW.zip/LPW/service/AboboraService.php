<?php 

require_once(__DIR__ . "/../model/Abobora.php");

class AboboraService {

    private Abobora $abobora;

    public function __construct()
    {
        $this->abobora = new Abobora();
    }

    public function criar($valor)
    {
        if (!$this->verificarSeExiste()) {
            $this->abobora->setAbobora($valor);
            $_SESSION[SESSAO_VALOR] = $this->abobora->getAbobora();
            return true;
        } else {
            return false;
        }
    }

    public function alterar()
    {
        if ($this->verificarSeExiste()) {
            $valorAtual = $_SESSION[SESSAO_VALOR];
            $novoValor = ($valorAtual + 1);
            $this->abobora->setAbobora($novoValor);
            $_SESSION[SESSAO_VALOR] = $this->abobora->getAbobora();
            return true;
        } else {
            return false;
        }
    }

    public function listar()
    {
        if ($this->verificarSeExiste()) {
            return $_SESSION[SESSAO_VALOR];
        } else {
            return false;
        }
    }

    public function remover()
    {
        if ($this->verificarSeExiste()) {
            //REMOVER OS DADOS DA SESSÃO
            session_unset();

            //DESTROI A SESSÃO
            session_destroy();
            return true;
        } else {
            return false;
        }
    }

    public function verificarSeExiste()
    {
        if (isset($_SESSION[SESSAO_VALOR])) {
            return true;
        } else {
            return false;
        }
    }

}