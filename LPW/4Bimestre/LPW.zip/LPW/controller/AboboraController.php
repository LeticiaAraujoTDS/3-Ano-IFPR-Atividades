<?php

require_once(__DIR__ . "/../service/AboboraService.php");

class AboboraController {

    private AboboraService $aboboraService;

    public function __construct()
    {
        $this->aboboraService = new AboboraService();
    }

    public function criar($valor) {
        return $this->aboboraService->criar($valor);
    }

    public function alterar() {
        return $this->aboboraService->alterar();
    }

    public function listar() {
        return $this->aboboraService->listar();
    }

    public function remover() {
        return $this->aboboraService->remover();
    }

    public function verificarSeExiste() {
        return $this->aboboraService->verificarSeExiste();
    }
}