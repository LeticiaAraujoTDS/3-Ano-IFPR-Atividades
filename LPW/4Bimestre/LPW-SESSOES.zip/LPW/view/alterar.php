<?php
require_once(__DIR__ . "/../controller/AboboraController.php");

$aboboraCont = new AboboraController();

$msgErro = $aboboraCont->alterar();

if (!$msgErro) {
    header("Location: ../view/home.php?msg=3");
    exit;
} else {
    header("Location: ../view/home.php");
    exit;
}