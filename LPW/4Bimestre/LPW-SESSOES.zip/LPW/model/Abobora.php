<?php

require_once(__DIR__ . "/../util/config.php");

class Abobora
{
    private int $abobora;

    public function __construct($a = 0)
    {
        $this->abobora = $a;
            }

    /**
     * Get the value of sessao
     */
    public function getAbobora(): int
    {
        return $_SESSION[SESSAO_VALOR] ?? $this->abobora;
    }

    /**
     * Set the value of sessao
     */
    public function setAbobora(int $abobora): self
    {
        $this->abobora = $abobora;
        $_SESSION[SESSAO_VALOR] = $this->abobora;
        return $this;
    }
}
