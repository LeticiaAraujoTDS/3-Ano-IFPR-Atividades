<?php

require_once(__DIR__ . "/../controller/DisciplinaController.php");

$idCurso = 0;//id de curso de exemplo
if (isset($_GET['id'])) {
    $idCurso = $_GET['id'];

}

$discConstroller = new DisciplinaController();
$disciplinas = $discConstroller->listarPorCurso($idCurso);

echo json_encode($disciplinas, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE); // o JSON_UNESCAPED_UNICODE é prara aparecer a palavra com acentuação