<?php

define("SESSAO_VALOR", "VALOR");
