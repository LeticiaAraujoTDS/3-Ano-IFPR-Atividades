<?php

require_once(__DIR__ . "/../util/config.php");

class Abobora
{
    private int $abobora;

    /**
     * Get the value of abobora
     */
    public function getAbobora(): int
    {
        return $this->abobora;
    }

    /**
     * Set the value of abobora
     */
    public function setAbobora(int $abobora): self
    {
        $this->abobora = $abobora;
        return $this;
    }
}
