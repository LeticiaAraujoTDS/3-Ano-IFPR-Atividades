<?php
require_once(__DIR__ . "/../controller/AboboraController.php");

$aboboraCont = new AboboraController();

$msg = $aboboraCont->criar(1);

if (!$msg) {
    header("Location: ../view/home.php?msg=0"); 
    exit;
} else {
    header("Location: ../view/home.php");
    exit;
}