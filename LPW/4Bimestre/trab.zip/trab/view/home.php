<?php
require_once(__DIR__ . "/../controller/AboboraController.php");

$aboboraCont = new AboboraController();

$mensagens = array(
    "<i class='bi bi-exclamation-triangle'></i> ERRO: O contador de abóboras já foi iniciado!",
    "<i class='bi bi-exclamation-triangle'></i> Sessão não existe! Crie o contador para começar a coletar abóboras."
);

$sessaoExiste = $aboboraCont->verificarSeExiste();
$contagemAboboras = $sessaoExiste ? $aboboraCont->listar() : 0;



if ($sessaoExiste) {
    if (isset($_GET['msg'])) {
        $msg_id = $_GET['msg'];
        if (isset($mensagens[$msg_id])) {
            $mensagem = $msg_id;
        }
    }
} else {
    $mensagem = 1;
}

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contador de Abóboras de Halloween</title>
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <!-- css -->
    <link rel="stylesheet" href="../styles/estilo.css">
    <!-- shortcut icon -->
    <link rel="shortcut icon" href="../img/abobora.png">
    <!-- fonte -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Mystery+Quest&display=swap" rel="stylesheet">
</head>

<body>
    <div class="container pt-3 pb-4 mt-3">
        <div class="titulo mt-2 d-flex justify-content-center">
            <img src="../img/abobora.png" class=" m-2"></img>
            <h2 class="m-2" style="font-family: Mystery Quest, Verdana, sans-serif;">Contador de Abóboras de Halloween (Sessão)</h2>
        </div>

        <div class="funcoes mt-3">
            <a class="btn btn-outline-light m-1 col-2" href="../view/criar.php"><i class="bi bi-plus"></i> Criar Contador</a>
            <a class="btn btn-outline-warning m-1 col-2" href="../view/alterar.php"><i class="bi bi-gift"></i> Coletar Abóbora</a>
            <a class="btn btn-outline-danger m-1 col-2" href="../view/remover.php"><i class="bi bi-trash3"></i> Deletar Sessão</a>
        </div>

        <div class="contador mt-4">
            <?php
            if ($sessaoExiste):
            ?>
                <p class="m-2 fw-bolder">Contagem Total:
                    <span class="fw-bold fs-5 text-warning">
                        <?= $contagemAboboras ?>
                    </span> abóbora(s).
                </p>
                <div class="abobora-display">
                    <?php
                    for ($i = 1; $i <= $contagemAboboras; $i++):
                    ?>
                        <div class="card bg-dark border-warning p-2" style="width: 100px;">
                            <div class="text-center">
                                <span class="fs-1"><img src="../img/abobora1.png" style="height: 64px; width: 64px;"></span>
                            </div>
                            <div class="card-body p-1 text-center">
                                <p class="card-text text-warning m-0">Abóbora #<?= $i ?></p>
                            </div>
                        </div>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
            <?php if ($mensagem != null): ?>
                <div class="msg text-danger">
                    <span><?= $mensagens[$mensagem] ?></span>
                </div>
            <?php endif; ?>
        </div>

    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>