<?php
require_once("../model/conexao.php");
class LivrosDao {
    private $con;
    public function __construct(){
       $this->con=(new Conexao())->conectar();
    }
function inserir($obj) {
    $sql = "INSERT INTO livros (id, titulo, genero, qtd_paginas, autor) VALUES (?, ?, ?, ?, ?)";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$titulo=$obj->getTitulo();
$genero=$obj->getGenero();
$qtd_paginas=$obj->getQtd_paginas();
$autor=$obj->getAutor();

    $stmt->execute([$id,$titulo,$genero,$qtd_paginas,$autor]);
}
function listaGeral() {
//fazer o tratamento do erro com o try catch
    $sql = "select * from livros";
    $query = $this->con->query($sql);
    $dados = $query->fetchAll(PDO::FETCH_ASSOC);//esse fetch_assoc pode ser o fetch_obj, pode ter os dois tratamentos
    return $dados;
}
}
?>