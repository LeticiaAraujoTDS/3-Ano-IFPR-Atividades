<html>
    <head>
        <title>Lista de Livros</title>
        <link rel="stylesheet" href "../css/estilos.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
        <?php
        require_once("../dao/LivrosDao.php");
    $dao = new livrosDao();
    $dados = $dao->listaGeral();
    ?>
    <div class="container d-flex justify-content-center align-items-center vh-100"> 
    <table class='table table-striped table-bordered table-hover shadow-sm'>
        <tr>
            <th><?='id' ?></th>
				<th><?='titulo' ?></th>
				<th><?='genero' ?></th>
				<th><?='qtd_paginas' ?></th>
				<th><?='autor' ?></th>
				
            <td>Editar</td>
            <td>Excluir</td>
        </tr>
        <?php foreach($dados as $dado): ?>
        <tr>
            <td><?= $dado['id'] ?></td>
				<td><?= $dado['titulo'] ?></td>
				<td><?= $dado['genero'] ?></td>
				<td><?= $dado['qtd_paginas'] ?></td>
				<td><?= $dado['autor'] ?></td>
				
            <td><img src="../img/btn_editar.png" alt=""></td>
            <td><img src="../img/btn_excluir.png" alt=""></td>
        </tr>
        <?php endforeach; ?>
    </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>