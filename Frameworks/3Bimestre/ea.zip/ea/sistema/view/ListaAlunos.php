<html>
    <head>
        <title>Lista de Alunos</title>
        <link rel="stylesheet" href "../css/estilos.css">
    </head>
    <body>
        <?php
        require_once("../dao/AlunosDao.php");
    $dao = new alunosDao();
    $dados = $dao->listaGeral();
    foreach($dados as $dado){
        <br>echo $dado['id']<br>echo $dado['nome']<br>echo $dado['idade']<br>echo $dado['estrangeiro']<br>echo $dado['id_curso'];
    }
    ?>

    </body>
</html>