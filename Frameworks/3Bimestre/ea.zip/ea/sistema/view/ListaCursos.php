<html>
    <head>
        <title>Lista de Cursos</title>
        <link rel="stylesheet" href "../css/estilos.css">
    </head>
    <body>
        <?php
        require_once("../dao/CursosDao.php");
    $dao = new cursosDao();
    $dados = $dao->listaGeral();
    foreach($dados as $dado){
        <br>echo $dado['id']<br>echo $dado['nome']<br>echo $dado['turno'];
    }
    ?>

    </body>
</html>