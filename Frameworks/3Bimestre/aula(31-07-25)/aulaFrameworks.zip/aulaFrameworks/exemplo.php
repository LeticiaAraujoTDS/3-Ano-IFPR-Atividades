<?php
//  echo "<hr><h1>Exemplo 1</h1>";

//  $tabela = [["nome" => "Adalberto", "idade" => "20"], ["nome" => "Asdrubaldo", "idade" => "30"]];
//  var_dump($tabela);
//  echo "<hr>";

 echo '<link rel="stylesheet" href="style.css">';

//  foreach ($tabela as $dado) {
//      $indice = array_values((array)$dado);
//      echo $indice[0] . "<br>";
//  }

// echo "<hr><h1>Exemplo 2</h1>";

// $dados = [
// (object) ["Field"=> "id", "Type" => "int(11)"],
// (object) ["Field"=> "nome", "Type" => "varchar(100)"],
// (object) ["Field"=> "idade", "Type" => "int(3)"]
// ];

// $atributos = array_map(function($obj) {
// return $obj->Field;
// }, $dados); 
// ["id", "nome","idade"] -> id,nome,idade (é isso que o implode faz)
// $str = implode(",", $atributos);
// echo $str;
// $placeholders = implode(",",array_fill(0,count($atributos),'?')); // o array_fill -> cria o vetor, ai prenche da [0] até o valor que o count deu, preenchendo com o ultimo parametro '?'
// echo "<br>".$placeholders;

$tabelas = [["nome_tabela" => "cidade"], ["nome_tabela" => "estado"]];

$atributos_cidade = [
    (object) ["Field" => "id", "Type" => "int(11)"],
    (object) ["Field" => "nome", "Type" => "varchar(100)"],
    (object) ["Field" => "idEstado", "Type" => "int(3)"],
    (object) ["Field" => "habitantes", "Type" => "int(5)"],
];

$atributos_estado = [
    (object) ["Field" => "id", "Type" => "int(11)"],
    (object) ["Field" => "nome", "Type" => "varchar(100)"],
    (object) ["Field" => "sigla", "Type" => "varchar(2)"]
];

$atributos_c = array_map(function ($obj) {
    return $obj->Field;
}, $atributos_cidade);

$atributos_c = [$atributos_c[1], $atributos_c[2], $atributos_c[3]];

$atributos_e = array_map(function ($obj) {
    return $obj->Field;
}, $atributos_estado);
$atributos_e = [$atributos_e[1], $atributos_e[2]];

$strc = implode(",", $atributos_c);

$stre = implode(",", $atributos_e);

$placeholders = implode(",", array_fill(0, count($atributos_cidade)-1, '?'));

$i = 0;
foreach ($atributos_c as $dado) {
    if ($dado == $atributos_c[3])
      continue;
      $indice = array_values((array)$dado);
      return "\$stmt->bindValue(\$i++, \$obj->get"."ucfirst($indice[0])());";
}

$conteudo = <<<EOT

\$sql = 'INSERT INTO cidade (\$strc) values (\$placeholders)';
\$stmt = \$this->con->prepare(\$sql);
\$stm-

EOT;