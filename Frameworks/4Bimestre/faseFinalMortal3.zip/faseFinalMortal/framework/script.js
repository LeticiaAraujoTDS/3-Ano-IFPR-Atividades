const tela = document.getElementsByTagName("tela")[0];

const canvas = document.createElement("canvas");
tela.appendChild(canvas);

canvas.width = tela.getAttribute("largura");
canvas.height = tela.getAttribute("altura");
canvas.style = "border: 1px solid black";
const ctx = canvas.getContext('2d');

desenhar();

function desenhar() {

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    for (const arco of document.getElementsByTagName("arco")) {

        let x = arco.getAttribute("px") || 20;
        let y = arco.getAttribute("py") || 20;
        let raio = arco.getAttribute("raio") || 20;
        let cor = arco.getAttribute("cor") || "blue";
        let corBorda = arco.getAttribute("corBorda") || "black";
        let anguloInicial = parseFloat(arco.getAttribute("anguloI") || 0);
        let anguloFinal = parseFloat(arco.getAttribute("anguloF") || Math.PI * 2);

        ctx.beginPath();
        ctx.arc(x, y, raio, anguloInicial, anguloFinal, false);
        ctx.fillStyle = cor;
        ctx.fill();
        ctx.strokeStyle = "black";
        ctx.stroke();
        ctx.closePath();
    }

}

function atualizar() {
    for (const arc of document.getElementsByTagName("arco")) {
        let arcoH = arc.getAttribute("moverH");
        let n = parseInt(arc.getAttribute("px"));

        let arcoV = arc.getAttribute("moverV");
        let y = parseInt(arc.getAttribute("py"));

        //horizontal
        arcoH === "direita" ? n += 2 : n -= 2;

        if (n > canvas.width) n = 0;
        if (n < 0) n = canvas.width;


        arc.setAttribute("px", n);

        //vertical
        arcoV === "acima" ? y -= 4 : y += 4;

        if (y > canvas.height) y = 0;
        if (y < 0) y = canvas.height;
        arc.setAttribute("py", y);

        //no final, mexe na diagonal !
    }
}

function animar() {
    desenhar();
    atualizar();
    requestAnimationFrame(animar);
}

animar();