
const canvas = document.getElementById('Canvas');
const ctx = canvas.getContext('2d');

//desenhanhdo o circulo
ctx.beginPath();//caminho por onde o caminho começa
ctx.arc(150, 100, 50, 0, Math.PI * 2, false);//x, y, raio do circulo, o 0 é o angulo inicial, o pi * 2 é a circunerencia e é = a 360 graus, false é o sentido anti-horario e true é o sentido horario
ctx.fillStyle = 'blue';
ctx.fill();
ctx.strokeStyle = 'black';
ctx.stroke();
ctx.closePath();

ctx.beginPath();
ctx.rect(50, 200, 200, 100); // os dois primeiros sao os pontos onde comeca o desenho, altura e largura
ctx.fillStyle = 'green';
ctx.fill();
ctx.strokeStyle = 'black';
ctx.stroke();
ctx.closePath();



ctx.beginPath();
ctx.moveTo(300,300); //primeiro ponto
ctx.lineTo(400, 300);//segundo ponto
ctx.lineTo(350, 200);//terceiro ponto
ctx.closePath();
ctx.fillStyle = 'red';
ctx.fill();
ctx.strokeStyle = 'black';
ctx.stroke();