const tela = document.getElementsByTagName("tela");
const canvas = document.createElement("canvas");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
const ctx = canvas.getContext('2d');
tela[0].appendChild(canvas);
//const arcos = document.getElementsByTagName("arco");
//com um for normal funcionou
// for (let index = 0; index < arcos.length; index++) 
for (const arco of document.getElementsByTagName("arco")) {
    desenhaArco(arco);   
}

function desenhaArco(arco) {

    //if (document.getElementsByTagName("arco").length > 0) {
        const x = arco.getAttribute("px");
        const y = arco.getAttribute("py");
        const raio = arco.getAttribute("raio");
        const cor = arco.getAttribute("cor") || "blue";
        const corBorda = arco.getAttribute("corBorda") || "black";
        const anguloInicial = arco.getAttribute("anguloI");
        const anguloFinal = arco.getAttribute("anguloF");
        const sentido = arco.getAttribute("sentido") || false;
        ctx.beginPath();
        ctx.arc(x, y, raio, anguloInicial, Math.PI * anguloFinal, sentido);
        ctx.fillStyle = cor;
        ctx.fill();
        ctx.strokeStyle = corBorda;
        ctx.stroke();
        ctx.closePath();
    //}

}