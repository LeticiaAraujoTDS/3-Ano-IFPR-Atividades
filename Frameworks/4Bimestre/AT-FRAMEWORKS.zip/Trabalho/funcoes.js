const tela = document.getElementById("tela");
const canvas = document.createElement("canvas");
canvas.width = tela.getAttribute("largura");
canvas.height = tela.getAttribute("altura");
const ctx = canvas.getContext("2d");
tela.appendChild(canvas);



// dados gerais
let dados = {
    px: document.getElementById("px"),
    py: document.getElementById("py"),
    cor: document.getElementById("cor")
};

const divFormaEscolhida = document.getElementById("formaEscolhida");
const select = document.getElementById("forma");
const formulario = document.getElementById("formulario");
const limparBotao = document.getElementById("apagar");

select.addEventListener("change", () => verificarTipo());

function verificarTipo() {
    const option = select.value;
    divFormaEscolhida.innerHTML = "";

    if (option === "r") {
        const alturaDiv = document.createElement("div");
        alturaDiv.className = "mb-3";

        const alturaLabel = document.createElement("label");
        alturaLabel.setAttribute("for", "altura");
        alturaLabel.className = "form-label";
        alturaLabel.textContent = "Informe a altura do retângulo: ";

        const alturaInput = document.createElement("input");
        alturaInput.setAttribute("id", "altura");
        alturaInput.setAttribute("type", "number");
        alturaInput.setAttribute("value", "100");
        alturaInput.className = "form-control";

        alturaDiv.appendChild(alturaLabel);
        alturaDiv.appendChild(alturaInput);
        divFormaEscolhida.appendChild(alturaDiv);

        const larguraDiv = document.createElement("div");
        larguraDiv.className = "mb-3";

        const larguraLabel = document.createElement("label");
        larguraLabel.setAttribute("for", "largura");
        larguraLabel.className = "form-label";
        larguraLabel.textContent = "Informe a largura do retângulo: ";

        const larguraInput = document.createElement("input");
        larguraInput.setAttribute("id", "largura");
        larguraInput.setAttribute("type", "number");
        larguraInput.setAttribute("value", "150");
        larguraInput.className = "form-control";

        larguraDiv.appendChild(larguraLabel);
        larguraDiv.appendChild(larguraInput);
        divFormaEscolhida.appendChild(larguraDiv);

    } else if (option === "p") {
        const qtdLadosDiv = document.createElement("div");
        qtdLadosDiv.className = "mb-3";

        const qtdLadosLabel = document.createElement("label");
        qtdLadosLabel.setAttribute("for", "qtdLados");
        qtdLadosLabel.className = "form-label";
        qtdLadosLabel.textContent = "Informe a quantidade de lados: ";

        const qtdLadosInput = document.createElement("input");
        qtdLadosInput.setAttribute("id", "qtdLados");
        qtdLadosInput.setAttribute("type", "number");
        qtdLadosInput.setAttribute("min", "3");
        qtdLadosInput.setAttribute("value", "5");
        qtdLadosInput.className = "form-control";

        qtdLadosDiv.appendChild(qtdLadosLabel);
        qtdLadosDiv.appendChild(qtdLadosInput);
        divFormaEscolhida.appendChild(qtdLadosDiv);

        const raioDiv = document.createElement("div");
        raioDiv.className = "mb-3";

        const raioLabel = document.createElement("label");
        raioLabel.setAttribute("for", "raio");
        raioLabel.className = "form-label";
        raioLabel.textContent = "Informe o valor do raio: ";

        const raioInput = document.createElement("input");
        raioInput.setAttribute("id", "raio");
        raioInput.setAttribute("type", "number");
        raioInput.setAttribute("value", "80");
        raioInput.className = "form-control";

        raioDiv.appendChild(raioLabel);
        raioDiv.appendChild(raioInput);
        divFormaEscolhida.appendChild(raioDiv);
    } else if (option === "c") {
        const raioDiv = document.createElement("div");
        raioDiv.className = "mb-3";

        const raioLabel = document.createElement("label");
        raioLabel.setAttribute("for", "raioArco");
        raioLabel.className = "form-label";
        raioLabel.textContent = "Informe o valor do raio: ";

        const raioInput = document.createElement("input");
        raioInput.setAttribute("id", "raioArco");
        raioInput.setAttribute("type", "number");
        raioInput.setAttribute("value", "20");
        raioInput.className = "form-control";

        raioDiv.appendChild(raioLabel);
        raioDiv.appendChild(raioInput);
        divFormaEscolhida.appendChild(raioDiv);

        const angIniDiv = document.createElement("div");
        angIniDiv.className = "mb-3";

        const angIniLabel = document.createElement("label");
        angIniLabel.setAttribute("for", "angIniInput");
        angIniLabel.className = "form-label";
        angIniLabel.textContent = "Informe o valor do angulo inicial: ";

        const angIniInput = document.createElement("input");
        angIniInput.setAttribute("id", "angIniInput");
        angIniInput.setAttribute("type", "number");
        angIniInput.setAttribute("value", "0");
        angIniInput.className = "form-control";

        angIniDiv.appendChild(angIniLabel);
        angIniDiv.appendChild(angIniInput);
        divFormaEscolhida.appendChild(angIniDiv);

        const angFDiv = document.createElement("div");
        angFDiv.className = "mb-3";

        const angFInput = document.createElement("input");
        angFInput.setAttribute("id", "angFInput");
        angFInput.setAttribute("type", "number");
        angFInput.setAttribute("value", "360");
        angFInput.className = "form-control";

        const angFLabel = document.createElement("label");
        angFLabel.setAttribute("for", "angFInput");
        angFLabel.className = "form-label";
        angFLabel.textContent = "Informe o valor do angulo final: ";

        angFDiv.appendChild(angFLabel);
        angFDiv.appendChild(angFInput);
        divFormaEscolhida.appendChild(angFDiv);

    }
}

function limparCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const formas = tela.querySelectorAll("arco, retangulo, poligono");
    formas.forEach(forma => forma.remove());
}

function desenharArco() {
    for (const arco of document.getElementsByTagName("arco")) {
        let px = parseFloat(arco.getAttribute("px") || 100);
        let py = parseFloat(arco.getAttribute("py") || 100);
        let cor = arco.getAttribute("cor") || "red";
        let r = parseFloat(arco.getAttribute("raio") || 15);
        let angIni = parseFloat(arco.getAttribute("angini") || 0);
        let angF = parseFloat(arco.getAttribute("angf") || 360);

        ctx.beginPath();
        ctx.arc(px, py, r, angIni, angF, false);
        ctx.fillStyle = cor;
        ctx.fill();
        ctx.closePath();
    }
}

function desenharRetangulo() {
    for (const retangulo of document.getElementsByTagName("retangulo")) {
        let px = parseFloat(retangulo.getAttribute("px") || 100);
        let py = parseFloat(retangulo.getAttribute("py") || 100);
        let largura = parseFloat(retangulo.getAttribute("largura") || 200);
        let altura = parseFloat(retangulo.getAttribute("altura") || 150);
        let cor = retangulo.getAttribute("cor") || "red";

        ctx.beginPath();
        ctx.rect(px, py, largura, altura);
        ctx.fillStyle = cor;
        ctx.fill();
        ctx.closePath();
    }
}

function desenharPoligono() {
    for (const poligono of document.getElementsByTagName("poligono")) {
        let qtdLados = parseInt(poligono.getAttribute("qtdLados")) || 5;
        let raio = parseFloat(poligono.getAttribute("raio")) || 50;
        let posx = parseFloat(poligono.getAttribute("px")) || 100;
        let posy = parseFloat(poligono.getAttribute("py")) || 100;
        let cor = poligono.getAttribute("cor") || "red";

        ctx.beginPath();
        //formula para fazer um poligono com n qtd lados
        const anguloPasso = 2 * Math.PI / qtdLados;
        let anguloAtual = - Math.PI / 2;

        let px = posx + raio * Math.cos(anguloAtual);
        let py = posy + raio * Math.sin(anguloAtual);
        ctx.moveTo(px, py);

        for (let i = 1; i <= qtdLados; i++) {
            anguloAtual += anguloPasso;

            px = posx + raio * Math.cos(anguloAtual);
            py = posy + raio * Math.sin(anguloAtual);

            ctx.lineTo(px, py);
        }

        ctx.closePath();
        ctx.fillStyle = cor;
        ctx.fill();
    }

}

function criarTagArco() {

    const arco = document.createElement("arco");
    const raio = document.getElementById("raioArco");
    const angIni = document.getElementById("angIniInput");
    const angF = document.getElementById("angFInput");
    const cor = document.getElementById("cor");
    const animarV = document.getElementById("animarV");
    const animarH = document.getElementById("animarH");

    arco.setAttribute("px", dados.px.value);
    arco.setAttribute("py", dados.py.value);
    arco.setAttribute("raio", raio.value);
    arco.setAttribute("angIni", angIni.value);
    arco.setAttribute("angF", angF.value);
    arco.setAttribute("cor", cor.value);
    arco.setAttribute("animarV", animarV.value);
    arco.setAttribute("animarH", animarH.value);

    tela.appendChild(arco);

}

function criarTagRetangulo() {

    const retangulo = document.createElement("retangulo");
    const altura = document.getElementById("altura");
    const largura = document.getElementById("largura");
    const cor = document.getElementById("cor");
    const animarV = document.getElementById("animarV");
    const animarH = document.getElementById("animarH");


    retangulo.setAttribute("px", dados.px.value);
    retangulo.setAttribute("py", dados.py.value);
    retangulo.setAttribute("altura", altura.value);
    retangulo.setAttribute("largura", largura.value);
    retangulo.setAttribute("cor", cor.value);
    retangulo.setAttribute("animarV", animarV.value);
    retangulo.setAttribute("animarH", animarH.value);
    tela.appendChild(retangulo);

}

function criarTagPoligono() {

    const poligono = document.createElement("poligono");
    const raio = document.getElementById("raio");
    const qtdLados = document.getElementById("qtdLados");
    const cor = document.getElementById("cor");
    const animarV = document.getElementById("animarV");
    const animarH = document.getElementById("animarH");

    poligono.setAttribute("px", dados.px.value);
    poligono.setAttribute("py", dados.py.value);
    poligono.setAttribute("raio", raio.value);
    poligono.setAttribute("qtdLados", qtdLados.value);
    poligono.setAttribute("cor", cor.value);
    poligono.setAttribute("animarV", animarV.value);
    poligono.setAttribute("animarH", animarH.value);
    tela.appendChild(poligono);

}

function desenhar() {
    const forma = select.value;
    if (forma === "r") {
        criarTagRetangulo();
        desenharRetangulo();
    } else if (forma === "p") {
        criarTagPoligono();
        desenharPoligono();
    } else if (forma === "c") {
        criarTagArco();
        desenharArco();
    }
}

function atualizarArco() {
    for (const arc of document.getElementsByTagName("arco")) {
        let animarV = arc.getAttribute("animarV")
        let animarH = arc.getAttribute("animarH")
        if (animarH !== "n") {
            let n = parseInt(arc.getAttribute("px"));
            (animarH === "direita") ? n += 2 : n -= 2;
            if (n > canvas.width) n = 0;
            if (n < 0) n = canvas.width;
            arc.setAttribute("px", n);
        }
        if (animarV !== "n") {
            let n = parseInt(arc.getAttribute("py"));
            (animarV === "abaixo") ? n += 2 : n -= 2;
            if (n > canvas.height) n = 0;
            if (n < 0) n = canvas.height;
            arc.setAttribute("py", n);
        }
    }
}
function atualizarRetangulo() {
    for (const ret of document.getElementsByTagName("retangulo")) {
        let animarV = ret.getAttribute("animarV")
        let animarH = ret.getAttribute("animarH")
        if (animarH !== "n") {
            let n = parseInt(ret.getAttribute("px"));
            (animarH === "direita") ? n += 2 : n -= 2;
            if (n > canvas.width) n = 0;
            if (n < 0) n = canvas.width;
            ret.setAttribute("px", n);
        }
        if (animarV !== "n") {
            let n = parseInt(ret.getAttribute("py"));
            (animarV === "abaixo") ? n += 2 : n -= 2;
            if (n > canvas.height) n = 0;
            if (n < 0) n = canvas.height;
            ret.setAttribute("py", n);
        }
    }
}
function atualizarPoligono() {
    for (const pol of document.getElementsByTagName("poligono")) {
        let animarV = pol.getAttribute("animarV")
        let animarH = pol.getAttribute("animarH")
        if (animarH !== "n") {
            let n = parseInt(pol.getAttribute("px"));
            (animarH === "direita") ? n += 2 : n -= 2;
            if (n > canvas.width) n = 0;
            if (n < 0) n = canvas.width;
            pol.setAttribute("px", n);
        }
        if (animarV !== "n") {
            let n = parseInt(pol.getAttribute("py"));
            (animarV === "abaixo") ? n += 2 : n -= 2;
            if (n > canvas.height) n = 0;
            if (n < 0) n = canvas.height;
            pol.setAttribute("py", n);
        }
    }
}
function animar() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    atualizarArco();
    atualizarPoligono();
    atualizarRetangulo();

    desenharArco();
    desenharPoligono();
    desenharRetangulo();

    requestAnimationFrame(animar);
}
animar();

formulario.addEventListener("submit", (e) => {
    e.preventDefault();
    desenhar();
});

limparBotao.addEventListener("click", (e) => {
    e.preventDefault();
    limparCanvas();
})